package PageObjects;

import Helper.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class EvmContractLocators extends BaseClass {

    public WebElement ContractOnsideBar(){
            WebElement ContractOnSideBar =driver.findElement(By.xpath("//ul/li/div/div/span[text() = 'Contract']"));
            return ContractOnSideBar;
    }

    public WebElement ListingOfContract(){
             WebElement ListingOfContract= driver.findElement(By.xpath("//a/span[text()='Contract Listing']"));
             return ListingOfContract;
    }

    public WebElement TotalNumberOfContracts(){
        WebElement TotalNumberOfContracts= driver.findElement(By.xpath("//section/div[@class='style_titleArea__Qk6S5 style_hasChildren__B6yxR']"));
        return TotalNumberOfContracts;
    }

    public WebElement DetailofContract(){
        WebElement DetailofContract= driver.findElement(By.xpath("//div[@class='style_button__Xl6wg']"));
        return DetailofContract;
    }


    public WebElement Holdertoggle(){
        WebElement Holdertoggle= driver.findElement(By.xpath("//button[text()='Holders']"));
        return Holdertoggle;
    }

    public WebElement InfoToggle(){
        WebElement InfoToggle= driver.findElement(By.xpath("//button[text()='Info']"));
        return InfoToggle;
    }

    public WebElement ContractToggle(){
       WebElement ContractToggle=driver.findElement(By.xpath("//button[text()='Contract']"));
       return ContractToggle;
    }





}
