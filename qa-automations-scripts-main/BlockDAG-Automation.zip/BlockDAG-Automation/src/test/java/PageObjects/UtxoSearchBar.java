package PageObjects;

import Helper.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class UtxoSearchBar extends BaseClass {

    public WebElement SearchBarInputFieldOnUtxo(){
        WebElement SearchBarInputFieldOnUtxo=driver.findElement(By.xpath("//input[@placeholder='Search by Address / Txn Hash / Block']"));
        return SearchBarInputFieldOnUtxo;
    }

    public WebElement GoBackToMainWebsite(){
        WebElement GoBackToMainWebsite= driver.findElement(By.xpath("//a[contains(text(),'Go Back to Main Website')]"));
        return GoBackToMainWebsite;
    }
}
